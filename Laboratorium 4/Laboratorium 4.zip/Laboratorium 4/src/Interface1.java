public interface Interface1 {
    int operacja(int a, int b);
}
